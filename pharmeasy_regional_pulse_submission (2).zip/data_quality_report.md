# Data Quality Report

| Dimension | Check | Result | Action |
|---|---|---|---|
| Accuracy | Region values mapped to `regions_master.csv` | 9 active canonical regions remain in orders | Normalize whitespace/case |
| Completeness | Missing `profit_inr` and `category` | 94 profit, 48 category values in raw data | Deterministic imputation |
| Consistency | Duplicate rows | 59 duplicate rows injected | Exact-row deduplication |
| Validity | Schema and numeric fields | Required schema enforced | `validate_schema()` gate |
| Referential integrity | Region master coverage | 10 master regions including Kurnool | LEFT JOIN preserves zero-order region |
| Uniqueness | `order_id` | 2,100 clean rows / unique IDs | Deduplicate before metrics |

The cleaning pipeline removes 59 duplicate rows, normalizes region spelling/case, fills category from the deterministic product-to-category lookup, and imputes missing profit using the category-level mean profit margin calculated from non-missing observations.
