import pandas as pd
def draft_report():
    df=pd.read_csv("region_month_metrics.csv")
    changes=df[df.month!="2026-04"].sort_values("mom_growth_pct",ascending=False)
    flagged=changes[changes.mom_growth_pct.abs()>10]
    lines=["# PharmEasy Regional Pulse — Draft Report","","## CII Insight Generator","The strongest verified month-over-month movements are listed below. These are descriptive signals, not causal claims.",""]
    for _,r in flagged.iterrows(): lines.append(f"- **{r.region} ({r.month})**: sales MoM {r.mom_growth_pct:+.2f}%.")
    lines += ["","## Evidence boundary","Metrics are calculated from the cleaned, deduplicated SQLite dataset. The dashboard should be used for drill-down before making operational decisions."]
    open("draft_report.md","w").write("\n".join(lines)); return "draft_report.md"
if __name__=="__main__": print(draft_report())
