# Presentation Storyline

## Executive — Situation / Complication / Resolution
- **Situation:** Regional performance is reported monthly across Telangana, Andhra Pradesh and Karnataka.
- **Complication:** Raw data contains duplicates, inconsistent region strings and missing values, so raw totals are not decision-safe.
- **Resolution:** A deterministic cleaning + SQLite metrics pipeline creates verified region/month signals and preserves Kurnool.
- **Recommendation:** Investigate significant region/month movements through category and product drill-down before taking action.

## Regional Manager — Overview / Category / Detail
- **Overview:** Start with orders, sales, profit and margin.
- **Category:** Explain which medicine/category drives the monthly movement.
- **Detail:** Drill into the affected region, products and order counts; separate verified evidence from hypotheses.
