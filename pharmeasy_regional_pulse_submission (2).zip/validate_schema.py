import pandas as pd
REQUIRED=["order_id","order_date","region","category","product","quantity","sales_inr","profit_inr"]
def validate_schema(df, required_columns):
    missing=[c for c in required_columns if c not in df.columns]
    if missing: return {"status":"blocked_schema","missing_columns":missing,"row_count":len(df)}
    return {"status":"validated","missing_columns":[],"row_count":len(df)}
if __name__=="__main__":
    df=pd.read_csv("orders_clean.csv"); print(validate_schema(df,REQUIRED)); print(validate_schema(df.drop(columns=["profit_inr"]),REQUIRED))
