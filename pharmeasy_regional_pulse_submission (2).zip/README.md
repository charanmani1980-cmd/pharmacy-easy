# PharmEasy Regional Pulse

## Run
```bash
python generate_dataset.py
python clean_data.py
python validate_schema.py
python build_db.py
python metrics_engine.py
python draft_report.py
python review_gate.py
streamlit run app.py
```

## Required submission artifacts
`generate_dataset.py`, `clean_data.py`, `data_quality_report.md`, `build_db.py`, `queries.sql`, `metrics_engine.py`, `draft_report.py`, `memo.md`, `review_gate.py`, `audit_log.jsonl`, `reliability_checklist.md`, `app.py`, `presentation_storyline.md`, `README.md`.
