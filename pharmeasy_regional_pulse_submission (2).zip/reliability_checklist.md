# Reliability Checklist

- [x] Generate dataset deterministically with fixed seed 2026.
- [x] Remove exact duplicate rows before analysis.
- [x] Normalize region strings against the master list.
- [x] Complete missing category using product-to-category lookup.
- [x] Impute missing profit using category-level mean profit margin.
- [x] Validate required schema and demonstrate blocked-schema path.
- [x] Build SQLite database and verify LEFT JOIN preserves Kurnool.
- [x] Use distinct order IDs for dashboard order KPI.
- [x] Compute region × month metrics and MoM change.
- [x] Persist monthly summaries as JSON state.
- [x] Separate descriptive findings from causal claims.
- [x] Review-gate decisions are restricted to approve/reject/edit and logged.
