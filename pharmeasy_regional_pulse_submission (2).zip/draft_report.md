# PharmEasy Regional Pulse — Draft Report

## CII Insight Generator
The strongest verified month-over-month movements are listed below. These are descriptive signals, not causal claims.

- **Guntur (2026-05)**: sales MoM +122.19%.
- **Visakhapatnam (2026-06)**: sales MoM +99.12%.
- **Tirupati (2026-05)**: sales MoM +66.87%.
- **Karimnagar (2026-05)**: sales MoM +23.63%.
- **Hyderabad (2026-06)**: sales MoM +20.61%.
- **Hyderabad (2026-05)**: sales MoM +16.29%.
- **Vijayawada (2026-06)**: sales MoM -12.02%.
- **Warangal (2026-06)**: sales MoM -14.84%.
- **Bengaluru (2026-05)**: sales MoM -15.02%.
- **Tirupati (2026-06)**: sales MoM -17.07%.
- **Warangal (2026-05)**: sales MoM -22.03%.
- **Guntur (2026-06)**: sales MoM -28.11%.
- **Karimnagar (2026-06)**: sales MoM -44.00%.
- **Visakhapatnam (2026-05)**: sales MoM -62.46%.

## Evidence boundary
Metrics are calculated from the cleaned, deduplicated SQLite dataset. The dashboard should be used for drill-down before making operational decisions.