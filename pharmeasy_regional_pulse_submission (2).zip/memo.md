# One-Page Recommendation Memo

**Title:** PharmEasy Regional Pulse — April to June 2026

**Context:** Regional operations need a reproducible view of orders, sales and profit across active markets, while preserving regions with zero orders.

**Key insight:** The metrics engine flags region/month changes above the 10% threshold for review. The largest verified movement should be investigated in the dashboard rather than interpreted as causal evidence.

**Evidence:** All metrics use the cleaned dataset after duplicate removal, region normalization, category completion and profit imputation. Kurnool is retained through the master-region LEFT JOIN.

**Recommendation:** Prioritize flagged region/month pairs for operational review; inspect category and product mix before changing inventory, promotions or staffing.

**Next check / assumptions:** Validate whether the movement persists in the next month and whether category mix, order count and average order value explain it.
