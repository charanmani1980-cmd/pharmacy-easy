import sqlite3, pandas as pd
DB="pharmeasy.db"
def build_db(db_path=DB):
    con=sqlite3.connect(db_path)
    pd.read_csv("regions_master.csv").to_sql("regions_master",con,if_exists="replace",index=False)
    pd.read_csv("orders_clean.csv").to_sql("orders_clean",con,if_exists="replace",index=False)
    con.execute("CREATE INDEX IF NOT EXISTS idx_orders_region_date ON orders_clean(region, order_date)")
    con.commit(); con.close(); print(f"Built {db_path}")
if __name__=="__main__": build_db()
