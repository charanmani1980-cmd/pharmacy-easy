-- 1. Row count
SELECT COUNT(*) AS row_count FROM orders_clean;
-- 2. Duplicate order IDs
SELECT order_id, COUNT(*) AS n FROM orders_clean GROUP BY order_id HAVING COUNT(*) > 1;
-- 3. Null check
SELECT COUNT(*) AS null_rows FROM orders_clean WHERE order_id IS NULL OR order_date IS NULL OR region IS NULL OR category IS NULL OR product IS NULL OR quantity IS NULL OR sales_inr IS NULL OR profit_inr IS NULL;
-- 4. Zero-order region survives the LEFT JOIN. COUNT(order_id), not COUNT(*), proves zero.
SELECT rm.region, COUNT(oc.order_id) AS order_count
FROM regions_master rm LEFT JOIN orders_clean oc ON rm.region=oc.region
GROUP BY rm.region ORDER BY order_count ASC, rm.region;
-- 5. Region x month sales and orders
SELECT region, substr(order_date,1,7) AS month, COUNT(DISTINCT order_id) AS orders, ROUND(SUM(sales_inr),2) AS sales_inr, ROUND(SUM(profit_inr),2) AS profit_inr
FROM orders_clean GROUP BY region, month ORDER BY region, month;
