import pandas as pd
RAW="pharmeasy_orders_raw.csv"; MASTER="regions_master.csv"; OUT="orders_clean.csv"
REQUIRED=["order_id","order_date","region","category","product","quantity","sales_inr","profit_inr"]
def load_and_clean(raw_path=RAW, master_path=MASTER):
    df=pd.read_csv(raw_path); master=pd.read_csv(master_path)
    df=df.drop_duplicates(subset=REQUIRED,keep="first").copy()
    canonical={r.lower().strip():r for r in master.loc[master.region!="Kurnool","region"]}
    df["region"]=df["region"].astype(str).str.strip().str.lower().map(canonical)
    product_to_category={}
    for cat, products in {"OTC Medicines":["Paracetamol 500mg","Cetirizine 10mg","ORS Sachet","Cough Syrup 100ml","Antacid Tablets"],"Prescription Medicines":["Metformin 500mg","Amlodipine 5mg","Atorvastatin 10mg","Azithromycin 500mg","Insulin Pen"],"Wellness & Nutrition":["Multivitamin Tablets","Whey Protein 1kg","Fish Oil Capsules","Immunity Booster Syrup","Calcium + D3 Tablets"],"Personal Care":["Sunscreen SPF50","Hand Sanitizer 500ml","Face Wash","Antiseptic Liquid","Baby Diaper Pack"],"Medical Devices":["Digital BP Monitor","Pulse Oximeter","Glucometer Kit","Nebulizer","Thermometer"],"Lab Tests":["Full Body Checkup","Thyroid Profile","Vitamin D Test","HbA1c Test","Lipid Profile"]}.items():
        for p in products: product_to_category[p]=cat
    df["category"]=df["category"].fillna(df["product"].map(product_to_category))
    df["sales_inr"]=pd.to_numeric(df.sales_inr,errors="coerce"); df["profit_inr"]=pd.to_numeric(df.profit_inr,errors="coerce")
    margins=(df.dropna(subset=["profit_inr"]).groupby("category").apply(lambda x:x.profit_inr.sum()/x.sales_inr.sum())).to_dict()
    df["profit_inr"]=df.apply(lambda r: round(r.sales_inr*margins[r.category],2) if pd.isna(r.profit_inr) else round(r.profit_inr,2),axis=1)
    df["quantity"]=pd.to_numeric(df.quantity,errors="raise").astype(int); df["order_date"]=pd.to_datetime(df.order_date).dt.strftime("%Y-%m-%d")
    df.to_csv(OUT,index=False)
    return df
if __name__=="__main__":
    x=load_and_clean(); print(x.shape); print(x.isna().sum())
