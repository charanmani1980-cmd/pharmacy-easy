import json, os
ALLOWED={"approve","reject","edit"}
def review_gate_v1(report_text, decision, reviewer, note="", log_path="audit_log.jsonl"):
    if decision not in ALLOWED: raise ValueError("decision must be approve, reject, or edit")
    if not reviewer: raise ValueError("reviewer is required")
    rec={"reviewer":reviewer,"decision":decision,"note":note,"report_excerpt":report_text[:500]}
    with open(log_path,"a") as f: f.write(json.dumps(rec)+"\n")
    return rec
def validate_audit_log(path="audit_log.jsonl"):
    if not os.path.exists(path): return False
    rows=[json.loads(x) for x in open(path) if x.strip()]
    return bool(rows) and all(r.get("decision") in ALLOWED for r in rows)
if __name__=="__main__":
    print(review_gate_v1(open("draft_report.md").read(),"approve","student","Reviewed metrics and evidence boundary."))
    print("audit_valid=",validate_audit_log())
