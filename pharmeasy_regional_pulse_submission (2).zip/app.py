import streamlit as st, pandas as pd, plotly.express as px, sqlite3, os
st.set_page_config(page_title="PharmEasy Regional Pulse",layout="wide")
st.title("PharmEasy Regional Pulse")
st.caption("Regional Performance Intelligence Pipeline — April to June 2026")
@st.cache_data
def load():
    con=sqlite3.connect("pharmeasy.db")
    df=pd.read_sql_query("SELECT * FROM orders_clean",con); con.close(); df["month"]=df.order_date.str[:7]; return df
try: df=load()
except Exception: st.error("Run generate_dataset.py, clean_data.py and build_db.py first."); st.stop()
orders=df.order_id.nunique(); sales=df.sales_inr.sum(); profit=df.profit_inr.sum(); margin=profit/sales*100
c1,c2,c3,c4=st.columns(4); c1.metric("Orders",f"{orders:,}"); c2.metric("Sales",f"₹{sales:,.0f}"); c3.metric("Profit",f"₹{profit:,.0f}"); c4.metric("Profit margin",f"{margin:.1f}%")
months=sorted(df.month.unique()); regions=sorted(df.region.unique()); cats=sorted(df.category.unique())
m1=st.selectbox("Month",months); reg=st.selectbox("Region",["All"]+regions); cat=st.selectbox("Category",["All"]+cats)
view=df.copy()
if reg!="All": view=view[view.region==reg]
if cat!="All": view=view[view.category==cat]
left,right=st.columns(2)
with left:
    trend=view.groupby("month",as_index=False).sales_inr.sum(); st.plotly_chart(px.line(trend,x="month",y="sales_inr",markers=True,title="Sales trend"),use_container_width=True)
with right:
    rs=view.groupby("region",as_index=False).sales_inr.sum().sort_values("sales_inr",ascending=False); st.plotly_chart(px.bar(rs,x="region",y="sales_inr",title="Sales by region"),use_container_width=True)
left,right=st.columns(2)
with left:
    cs=view.groupby("category",as_index=False).sales_inr.sum(); st.plotly_chart(px.bar(cs,x="category",y="sales_inr",title="Sales by category"),use_container_width=True)
with right:
    ps=view.groupby("product",as_index=False).sales_inr.sum().nlargest(10,"sales_inr"); st.plotly_chart(px.bar(ps,x="sales_inr",y="product",orientation="h",title="Top products"),use_container_width=True)
st.subheader("Region × month detail")
detail=df.groupby(["region","month"],as_index=False).agg(orders=("order_id","nunique"),sales_inr=("sales_inr","sum"),profit_inr=("profit_inr","sum")); detail["mom_growth_pct"]=detail.groupby("region").sales_inr.pct_change().fillna(0)*100
st.dataframe(detail.round(2),use_container_width=True)
MD
cat > /mnt/data/pharmeasy_submission/presentation_storyline.md <<'MD'
# Presentation Storyline

## Executive / Simulation–Complication–Resolution
- **Situation:** Regional performance is reported monthly across Telangana, Andhra Pradesh and Karnataka.
- **Complication:** Data contains duplicates, inconsistent region strings and missing values, so raw totals are not decision-safe.
- **Resolution:** A deterministic cleaning + SQLite metrics pipeline creates verified region/month signals and preserves Kurnool.
- **Recommendation:** Investigate significant region/month movements through category and product drill-down before taking action.

## Regional Manager / Overview–Category–Detail
- **Overview:** Start with orders, sales, profit and margin.
- **Category:** Explain which medicine/category drives the monthly movement.
- **Detail:** Drill into the affected region, products and order counts; separate verified evidence from hypotheses.
MD
cat > /mnt/data/pharmeasy_submission/README.md <<'MD'
# PharmEasy Regional Pulse

## Run
```bash
python generate_dataset.py
python clean_data.py
python validate_schema.py
python build_db.py
python metrics_engine.py
python draft_report.py
python review_gate.py
streamlit run app.py
```

## Files
- generate_dataset.py — deterministic raw dataset generator
- clean_data.py — cleaning pipeline
- validate_schema.py — schema gate
- data_quality_report.md — Part 1 report
- build_db.py / queries.sql — SQLite layer and verification SQL
- metrics_engine.py — metrics, MoM and persistence
- draft_report.py / memo.md — CII narrative and recommendation memo
- review_gate.py / audit_log.jsonl — human review gate and audit log
- reliability_checklist.md — reliability controls
- app.py — Streamlit + Plotly dashboard
- presentation_storyline.md — stakeholder reframing
MD
cd /mnt/data/pharmeasy_submission && python generate_dataset.py && python clean_data.py && python validate_schema.py && python build_db.py && python metrics_engine.py && python draft_report.py && python review_gate.py
zip -qr /mnt/data/pharmeasy_regional_pulse_submission.zip . -x '__pycache__/*' '*.pyc'
ls -lh /mnt/data/pharmeasy_regional_pulse_submission.zip
