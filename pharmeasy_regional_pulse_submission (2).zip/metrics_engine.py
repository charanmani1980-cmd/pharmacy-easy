import sqlite3, json, os
import pandas as pd
DB="pharmeasy.db"
def compute_percentage_change(current, previous):
    return 0.0 if previous in (0,None) else (current-previous)/previous*100.0
def region_month_metrics(db=DB):
    con=sqlite3.connect(db)
    q='''SELECT region, substr(order_date,1,7) month, COUNT(DISTINCT order_id) orders, SUM(sales_inr) sales_inr, SUM(profit_inr) profit_inr FROM orders_clean GROUP BY region, month ORDER BY region, month'''
    df=pd.read_sql_query(q,con); con.close(); df["sales_inr"]=df.sales_inr.round(2); df["profit_inr"]=df.profit_inr.round(2)
    df["mom_growth_pct"]=df.groupby("region")["sales_inr"].pct_change().fillna(0).mul(100).round(2)
    return df
def flag_significant_regions(changes, threshold=10):
    return {r: abs(v)>threshold for r,v in changes.items()}
def save_state(month, summary, path="state.json"):
    state={}
    if os.path.exists(path):
        with open(path) as f: state=json.load(f)
    state[month]=summary
    with open(path,"w") as f: json.dump(state,f,indent=2)
    return state
def load_previous_state(path="state.json"):
    if not os.path.exists(path): return {}
    with open(path) as f: return json.load(f)
def run_metrics():
    df=region_month_metrics(); df.to_csv("region_month_metrics.csv",index=False)
    for _,r in df[df.month!="2026-04"].iterrows():
        if abs(r.mom_growth_pct)>10: print(f"SIGNIFICANT: {r.region} {r.month} {r.mom_growth_pct:+.2f}%")
    for month,g in df.groupby("month"): save_state(month,g.to_dict("records"))
    return df
if __name__=="__main__": run_metrics()
